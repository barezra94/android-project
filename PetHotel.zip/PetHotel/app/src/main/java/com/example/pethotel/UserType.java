package com.example.pethotel;

public enum UserType {
    Manager,
    PetOwner
}
