package com.example.pethotel;

public abstract class Animal {

}
